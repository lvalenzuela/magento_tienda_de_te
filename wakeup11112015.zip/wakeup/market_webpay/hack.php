<html><body>Usted sera redirigido en 5 segundos al sitio seguro de webpay.<form action="/cgi-bin/tbk_bp_pago.cgi" id="webpay_standard_checkout" name="webpay_standard_checkout" method="POST"><div><input name="form_key" type="hidden" value="KxqwLsIGhA9G7ylM" /></div><input id="TBK_TIPO_TRANSACCION" name="TBK_TIPO_TRANSACCION" value="TR_NORMAL" type="hidden"/>
<input id="TBK_ID_SESION" name="TBK_ID_SESION" value="1" type="hidden"/>
<input id="TBK_URL_EXITO" name="TBK_URL_EXITO" value="http://www.estosipuedo.cl/index.php/webpay/standard/success/" type="hidden"/>
<input id="TBK_URL_FRACASO" name="TBK_URL_FRACASO" value="http://www.estosipuedo.cl/index.php/FRACASO?___store=default/" type="hidden"/>
<input id="TBK_ORDEN_COMPRA" name="TBK_ORDEN_COMPRA" value="100000416" type="hidden"/>
<input id="TBK_MONTO" name="TBK_MONTO" value="1221.00" type="hidden"/>
<input id="E_Comercio" name="E_Comercio" value="f6ea7a5d1764d1198976c437895721c0 " type="hidden"/>
<input id="NombreItem" name="NombreItem" value="LILIBLUE EDS (x 1) " type="hidden"/>
<input id="NroItem" name="NroItem" value="363" type="hidden"/>
<input id="TipoMoneda" name="TipoMoneda" value="1" type="hidden"/>
<input id="trx_id" name="trx_id" value="363" type="hidden"/>
<input id="producto" name="producto" value="LILIBLUE EDS (x 1) " type="hidden"/>
<input id="usr_tel_numero" name="usr_tel_numero" value="(562) 555-55-55" type="hidden"/>
<input id="Mensaje" name="Mensaje" value="0" type="hidden"/>
<input id="DireccionEnvio" name="DireccionEnvio" value="0" type="hidden"/>
</form><script type="text/javascript">document.getElementById("webpay_standard_checkout").submit();</script></body></html>